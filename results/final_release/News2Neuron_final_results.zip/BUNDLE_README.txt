News2Neuron final results bundle

Open results/final_release/index.html for the final conclusion and downloads.
Included: final score tables, PDF, reports, methods, validation logs, and raw article/control neural trials.
Full source, training models and earlier experiments: https://github.com/hwanghj09/News2Neuron
Publisher full text and private feature caches are not included.
BUNDLE_MANIFEST.json records SHA-256 for every packaged file except the manifest itself and this note.
